﻿namespace Task2
{
    public class UpdateTimeTask 
    {
       public static HiddenCamera _hiddenCamera;
        public static void Kamera()
        {
            _hiddenCamera.TakePhoto();
        }
    }
}